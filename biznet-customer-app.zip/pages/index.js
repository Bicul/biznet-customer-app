import { useEffect, useState } from 'react';

export default function Home() {
  const [data, setData] = useState([]);
  const [search, setSearch] = useState('');

  useEffect(() => {
    fetch('/api/customers')
      .then(res => res.json())
      .then(setData);
  }, []);

  const filtered = data.filter(row =>
    row.BP_FULLNAME.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-4">
      <h1 className="text-xl font-bold mb-4">Data Customer Biznet</h1>
      <input
        type="text"
        placeholder="Cari nama customer..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="border p-2 mb-4 w-full"
      />
      <table className="w-full border">
        <thead>
          <tr>
            <th className="border p-2">Nama</th>
            <th className="border p-2">Nomor Kontrak</th>
            <th className="border p-2">Status</th>
          </tr>
        </thead>
        <tbody>
          {filtered.map((row, i) => (
            <tr key={i}>
              <td className="border p-2">{row.BP_FULLNAME}</td>
              <td className="border p-2">{row.CONTRACTNUMBER}</td>
              <td className="border p-2">{row.STATUS}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
